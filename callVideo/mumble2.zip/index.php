<?php
header("Location: lobby.html");
